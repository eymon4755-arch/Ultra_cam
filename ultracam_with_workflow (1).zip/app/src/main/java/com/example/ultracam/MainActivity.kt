package com.example.ultracam

import android.Manifest
import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            UltraCamApp()
        }
    }
}

@Composable
fun UltraCamApp() {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var recording by remember { mutableStateOf<Recording?>(null) }
    var isRecording by remember { mutableStateOf(false) }
    var previewViewRef by remember { mutableStateOf<PreviewView?>(null) }

    val cameraProviderFuture = remember { ProcessCameraProvider.getInstance(context) }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permissions ->
        if (permissions.values.all { it }) {
            setupCamera(context, cameraProviderFuture, previewViewRef)
        }
    }

    LaunchedEffect(Unit) {
        permissionLauncher.launch(arrayOf(
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO
        ))
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("UltraCam") }) },
        content = { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                AndroidView(factory = {
                    PreviewView(it).apply {
                        this.scaleType = PreviewView.ScaleType.FILL_CENTER
                        previewViewRef = this
                        setupCamera(context, cameraProviderFuture, this)
                    }
                }, modifier = Modifier.fillMaxSize())

                FloatingActionButton(
                    onClick = {
                        if (isRecording) {
                            recording?.stop()
                            isRecording = false
                        } else {
                            coroutineScope.launch {
                                val recorder = Recorder.Builder()
                                    .setQualitySelector(QualitySelector.from(Quality.UHD, FallbackStrategy.lowerQualityOrHigherThan(Quality.FHD)))
                                    .build()
                                val videoCapture = VideoCapture.withOutput(recorder)

                                val file = createOutputFile(context)
                                val outputOptions = FileOutputOptions.Builder(file).build()

                                val activeRecording = videoCapture.output
                                    .prepareRecording(context, outputOptions)
                                    .apply { withAudioEnabled() }
                                    .start(ContextCompat.getMainExecutor(context)) { event ->
                                        when (event) {
                                            is VideoRecordEvent.Finalize -> {
                                                val uri = event.outputResults.outputUri
                                                println("Saved video to: $uri")
                                            }
                                        }
                                    }

                                recording = activeRecording
                                isRecording = true
                            }
                        }
                    },
                    containerColor = if (isRecording) Color.Red else Color.White,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(32.dp)
                        .size(72.dp),
                    shape = CircleShape
                ) {}
            }
        }
    )
}

fun setupCamera(context: Context, providerFuture: ListenableFuture<ProcessCameraProvider>, previewView: PreviewView?) {
    providerFuture.addListener({
        val cameraProvider = providerFuture.get()
        val preview = Preview.Builder()
            .setTargetResolution(android.util.Size(3840, 2160)) // 4K
            .build()
            .also { it.setSurfaceProvider(previewView?.surfaceProvider) }

        val recorder = Recorder.Builder()
            .setQualitySelector(QualitySelector.from(Quality.UHD, FallbackStrategy.lowerQualityOrHigherThan(Quality.FHD)))
            .build()

        val videoCapture = VideoCapture.withOutput(recorder)

        try {
            cameraProvider.unbindAll()
            cameraProvider.bindToLifecycle(
                context as ComponentActivity,
                CameraSelector.DEFAULT_BACK_CAMERA,
                preview,
                videoCapture
            )
        } catch (exc: Exception) {
            exc.printStackTrace()
        }
    }, ContextCompat.getMainExecutor(context))
}

fun createOutputFile(context: Context): File {
    val dir = File(context.getExternalFilesDir(null), "UltraCamVideos")
    if (!dir.exists()) dir.mkdirs()
    val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
    return File(dir, "VID_${'$'}timestamp.mp4")
}
